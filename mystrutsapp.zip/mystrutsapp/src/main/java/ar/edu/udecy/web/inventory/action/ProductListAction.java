package ar.edu.udecy.web.inventory.action;

public class ProductListAction {
}
